
var customAlert = function($state,$type,$text){
	if(!$state){
		$state = "show";
	}
	if(!$type){
		$state = "sucess";
		
	}
	if(!$text){
		$text = "sucess";
	}
	
 var resetAlert = function($type){
	 $(document).find("div.alert").removeClass("alert-"+$type).html("").fadeOut("slow");
     }
	$(document).find("div.alert").addClass($type ? "alert-"+$type :"alert-sucess").html($text);
	 if($state=="show"){
	 $("div.alert").fadeIn("slow");
	 }
	 else{
	 resetAlert($type);
	 }
	 

	
    
	
}





