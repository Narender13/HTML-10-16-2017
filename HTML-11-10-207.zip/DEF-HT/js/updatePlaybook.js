var elems = [];
dragula([$("#dragable-wrapper").get(0)])
    .on("dragend", function(el, target, src) {
        elems = []; // reset elems
        $(".dragable").each(function(idx, elem) {
            elems.push($(elem).attr("id"));
        });

        console.log(elems);

        // validate elems are in correct order
    });
let playbookDetails = {
    //-------- Method to open single div in edittable mode ---------//
    switchToEdit: function(parentEle) {
        if (parentEle) {
            let $ele = $(parentEle);
            $ele.find(".content + .custom-group textarea").val($ele.find(".content").text());
            $ele.find(".content,.iconSmall").addClass("hide"), $ele.find(".content + .custom-group").removeClass("hide");
        } else {
            throw new Error('form-group element not found');
        }
    },

    //-------- Method to cancel  single edittable textarea  ---------//
    switchBack: function(parentEle) {
        if (parentEle) {
        let $ele = $(parentEle);
      
            $ele.find(".content").addClass("hide"), $ele.find(".content + .custom-group textarea").val($ele.find(".content").text());
            $ele.find(".content,.iconSmall").removeClass("hide"), $ele.find(".content + .custom-group").addClass("hide");
        } else {
            throw new Error('form-group element not found');
        }
    },


    //-------- Method to open multiple div in edittable mode ---------//
    multipleswitchToEdit: function(parentEle, name) {
        let attrname = $(name).attr("data-name");
         if (parentEle) {
        let $ele = $(parentEle);
   
        var contentList = [];
        $ele.find(".content").each(function() {
            contentList.push($(this).text());
        });

        function closeContent() {
            $ele.find(".custom-group .textContentList").empty();
            console.log(contentList);
            for (let i = 0; i < contentList.length; i++) {
                $ele.find(".custom-group .textContentList").append('<input name=' + attrname + i + ' type="text" class="margin-bottom-10 custom-control light-12  col-sm-8" value="' + contentList[i] + '"/>' +
                    '<label class="checkcontainer col-sm-4"><input type="checkbox" value="checked"><span class="checkmark btn-red"></span>Remove item.</label><div class="clearfix"></div>');
            }
        }
        closeContent();
        $ele.find(".content,.iconSmall").addClass("hide"), $ele.find(".custom-group").removeClass("hide");
         }else{
           throw new Error('form-group element not found');
         }
    },


    //-------- Method to cancel  multiple  edittable inputs  ---------//

    multipleSwitchBack: function(parentEle) {
        let $ele = $(parentEle);
        $ele.find(".content,.iconSmall").removeClass("hide"), $ele.find(".custom-group").addClass("hide");
    },


    //-------- Method to open multiple files  in edittable mode ---------//

    fileSwitchToEdit: function(parentEle, name) {
        let attrname = $(name).attr("data-name");
        if (parentEle) {
        let $ele = $(parentEle);
        
        var filecontentList = [];
        $ele.find(".content").each(function() {
            filecontentList.push($(this).text());
        });
        $ele.find(".content,.iconSmall").addClass("hide"), $ele.find(".custom-group").removeClass("hide");

        function filecloseContent() {
            $ele.find(".custom-group .fileItemList").empty();
            console.log(filecontentList);
            for (let i = 0; i < filecontentList.length; i++) {
                $ele.find(".custom-group .fileItemList").append(
                    '<div class="col-sm-1 no-padding-left iconSmall margin-bottom-15">' +
                    '<img class="pull-left"src="img/icon-pdf.png"alt="Edit Icon">' +
                    '</div>' +
                    '<div class="col-sm-4 light-12 lightBlue margin-bottom-15">' + filecontentList[i] + ' </div>' +
                    '<label class="checkcontainer col-sm-7 "><input type="checkbox" value="checked"><span class="checkmark btn-red"></span>Delete ' + attrname + '</label>' +
                    '<div class="clearfix"></div>');
            }

        }
        filecloseContent();
          } else{
             throw new Error('form-group element not found');
          }

    },

    //-------- Method to cancel multiple editable files  ---------//

    fileSwitchToBack: function(parentEle) {
        let $ele = $(parentEle);
        $ele.find(".content,.iconSmall").removeClass("hide"), $ele.find(".custom-group").addClass("hide");
    },

    //-------- Method to open images in edittable mode ---------//
    imagesSwitchToEdit: function(parentEle, name) {
      
        let attrname = $(name).attr("data-name");
        if (parentEle) {
        let $ele = $(parentEle);

        var imagespathList = [];
        $ele.find(".content img").each(function() {
            imagespathList.push($(this).attr("src"));
        });
        $ele.find(".content").addClass("hide"), $ele.find(".custom-group").removeClass("hide");

        function imagescloseContent() {
            $ele.find(".custom-group .imageItemList").empty();
            console.log(imagespathList);
            for (let i = 0; i < imagespathList.length; i++) {
                $ele.find(".custom-group .imageItemList").append(
                    '<div class="col-sm-4 no-padding-left">' +
                    '<img class="photo" src="' + imagespathList[i] + '" alt="Edit Icon">' +
                    '<div class="padding-left-10 margin-top-10"><label class="checkcontainer padding-left-30"><input type="checkbox" value="checked"><span class="checkmark btn-red no-gutter-left"></span>Delete ' + attrname + '</label></div>' +
                    '<div class="clearfix"></div>');
            }

        }
        imagescloseContent();
        } else{
           throw new Error('form-group element not found');
        }
    },
     //-------- Method to cancel multiple editable images  ---------//
    imagesSwitchToBack : function(parentEle) {
        let $ele = $(parentEle);
        $ele.find(".content,.iconSmall").removeClass("hide"), $ele.find(".custom-group").addClass("hide");
    },
    

    event: function() {
        $("#savePlaybook").on("click", function() {
          // let curStep = $(this).closest(".form-horizontal");
             //curInputs = curStep.find("textarea,input[type='text']"),
            // isValid = true;
               
                     
                   //$(".form-group").removeClass("has-error");
                   // for (let i = 0; i < curInputs.length; i++) {
                    // if (!curInputs[i].validity.valid &&  $(curInputs[i]).is(":visible")) {
                        // isValid = false;
                        // $(curInputs[i]).closest(".form-group").addClass("has-error");
                    // }
                // }
        });
    }

}

playbookDetails.event();