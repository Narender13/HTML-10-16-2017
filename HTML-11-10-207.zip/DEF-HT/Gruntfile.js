
module.exports = function (grunt) {
    // ===========================================================================
    // CONFIGURE GRUNT ===========================================================
    // ===========================================================================
    grunt.initConfig({
        // get the configuration info from package.json ----------------------------
        pkg: grunt.file.readJSON('package.json'), // all of our configuration will go here


        concat: {
            options: {
                separator: '',
                // the banner is inserted at the top of the output
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },

            js: {
                src: ['js/bootstrap.js','js/bootstrap-select.js','js/general.js'],
                dest: 'main/js/main.js',
            },


        },

        // configure SASS to merge all css and convert to css -----------------------
        sass: {
            dev: {
                src: ['scss/main.scss'],
                dest: 'main/css/global.css',
            },

        },
        // configure uglify to minify js files -------------------------------------

        cssmin: {
            css: {
                src: 'main/css/global.css',
                dest: 'main/css/minify/<%= pkg.name %>.min.css'
            }
        },
        uglify: {
            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },
            dist: {
                files: {
                    'main/minify/<%= pkg.name %>.min.js': ['main/js/main.js']
                }
            }
        },
        // configure watch to auto update ----------------
        watch: {
            src: {
                files: ['dashboard.html'],
                tasks: ['copy'],
            }, // for stylesheets, watch css and less files 
            // only run less and cssmin 
            // for scripts, run jshint and uglify 
            scripts: {
                files: ['js/general.js', 'scss/base/*.scss', 'scss/layouts/*.scss', 'scss/modules/*.scss', 'scss/main.scss'],
                tasks: ['jshint', 'concat', 'uglify', 'cssmin'],

            },



        },


    });
    // LOAD GRUNT PLUGINS ========================================================
    // we can only load these if they are in our package.json
    // make sure you have run npm install so our app can find these
    //grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-watch');


    //grunt.loadNpmTasks('grunt-contrib-copy');
    // grunt.loadNpmTasks('grunt-contrib-htmlmin'); // grunt.loadNpmTasks('grunt-contrib-imagemin');
    // ============= // CREATE TASKS ========== //
    grunt.registerTask('default', ['concat', 'sass', 'cssmin', 'uglify', 'watch']);
}
    ;